## TRS-WAS远程命令执行

```
/mas/sysinfo/testCommandExecutor.jsp
```
